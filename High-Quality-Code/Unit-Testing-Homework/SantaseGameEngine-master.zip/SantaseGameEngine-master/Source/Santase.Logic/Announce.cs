﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Santase.Logic
{
    public enum Announce
    {
        None = 0,
        Twenty = 20,
        Fourty = 40,
    }
}
